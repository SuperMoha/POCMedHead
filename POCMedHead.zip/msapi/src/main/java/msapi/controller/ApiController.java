package msapi.controller;

import mshopital.model.Hopital;
import mshopital.service.HopitalService;
import mspatient.model.Patient;
import mspatient.service.PatientService;
import msspecialite.model.Specialite;
import msspecialite.service.SpecialiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ApiController {

    @Autowired
    private HopitalService hopitalService;

    @Autowired
    private SpecialiteService specialiteService;

    @Autowired
    private PatientService patientService;

    @GetMapping("/hopitaux")
    public List<Hopital> getHopitaux() {
        return hopitalService.getAllHopitaux();
    }

    @GetMapping("/patients")
    public List<Patient> getPatients() {
        return patientService.getAllPatient();
    }

    @GetMapping("/specialites")
    public List<Specialite> getSpecialites() {
        return specialiteService.getAllSpecialite();
    }


}
