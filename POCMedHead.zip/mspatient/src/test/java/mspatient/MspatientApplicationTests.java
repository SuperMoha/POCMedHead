package mspatient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MspatientApplicationTests {

	@Test
	void contextLoads() {
	}

}
